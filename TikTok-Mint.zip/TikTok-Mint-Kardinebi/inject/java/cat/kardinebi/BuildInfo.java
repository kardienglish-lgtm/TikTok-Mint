package cat.kardinebi;

/** Written by the build. Do not edit. */
final class BuildInfo {
    private BuildInfo() {}
    static final int PATCHED_DEX = 40;
    static final int TOTAL_DEX = 53;
    static final int REWRITES = 56014;
    static final int STATIC_TARGETS = 2;
    static final boolean APPEARANCE_ONLY = false;
    static final boolean MINT_PROFILE = false;
}
